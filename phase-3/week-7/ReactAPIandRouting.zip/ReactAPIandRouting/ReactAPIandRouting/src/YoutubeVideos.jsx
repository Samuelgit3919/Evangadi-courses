import { useEffect, useState } from "react";
import "./YoutubeVideos";
// api_key = AIzaSyA_88zaMcmAGsRPRcCEkm2RYZiYdvve7jI
const YoutubeVideos = () => {
  const [videos, setVideos] = useState([]);
  useEffect(() => {
    fetch(
      "https://youtube.googleapis.com/youtube/v3/search?part=snippet&channelId=UCE_M8A5yxnLfW0KghEeajjw&maxResults=10&order=date&key=AIzaSyA_88zaMcmAGsRPRcCEkm2RYZiYdvve7jI"
    )
      .then((res) => res.json())
      .then((res) => {
        const realItem = res.items;
        setVideos(realItem);
        // console.log(videos);
      });
  }, []);
  // https://www.youtube.com/watch?v=mdtcSIAiqRc
  return (
    <main>
      <h1>Apple YouTube Api</h1>
      <div className="card-wrapper">
        {videos.map((data) => (
          <div key={data.id} className="card">
            <a
              href={`https://www.youtube.com/watch?v=${data.id.videoId}`}
              target="_blank"
            >
              <img src={data.snippet.thumbnails.high.url} alt="" />
            </a>
            <h4>{data.snippet.title}</h4>
            <p>{data.snippet.description}</p>
          </div>
        ))}
      </div>
    </main>
  );
};

export default YoutubeVideos;
