import SectionOne from "./components/Main/SectionOne";
import SectionTwo from "./components/Main/SectionTwo";
import SectionThree from "./components/Main/SectionThree";
import SectionFour from "./components/Main/SectionFour";
import SectionFive from "./components/Main/SectionFive";
import Sectionsix from "./components/Main/Sectionsix";
import Alert from "./components/Main/Alert";
import YoutubeVideos from "./components/YoutubeVideos";

const RouteGroup = () => {
  return (
    <>
      <SectionOne />
      <SectionTwo />
      <SectionThree />
      <SectionFour />
      <SectionFive />
      <Sectionsix />
      <Alert />
      <YoutubeVideos />
    </>
  );
};

export default RouteGroup;
